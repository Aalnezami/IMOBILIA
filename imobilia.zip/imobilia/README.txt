les attributs d'un bien
1- essentiel
  - nombre de puèses
  - surface 
  - nombre de sall de bain
  - séjour
2- intérieur
  - ascenseur
  - cuisine équipée
  - interphone 
  - didgicode 
3- extérieur
  - terrrasse 
  - garage 
  - parking 
4- Autre 
  - année de construction
  - matière de construction
  - nombre d'étage
